// Explore the Solar System - Show solar system view and hide initial elements
document.getElementById('transition-button').addEventListener('click', function() {
    const splineFrame = document.getElementById('spline-frame');
    const solarFrame = document.getElementById('solar-frame');
    const transitionButton = document.getElementById('transition-button');
    const loadingSpinner = document.getElementById('loading-spinner');
    const talkToSunButton = document.getElementById('talk-to-sun');

    // Show loading spinner and fade out initial view
    loadingSpinner.classList.remove('hidden');
    splineFrame.style.opacity = "0";
    transitionButton.style.opacity = "0";

    setTimeout(() => {
        splineFrame.style.display = "none"; // Hide initial frame
        transitionButton.style.display = "none";
        loadingSpinner.classList.add('hidden'); // Hide loading spinner
        
        // Show solar system frame and "Talk to Sun" button
        solarFrame.style.display = "block";
        solarFrame.style.opacity = "1"; // Fade-in effect
        talkToSunButton.classList.remove('hidden');
    }, 500); // Adjust delay to match fade-out duration
});

// Talk to Sun - Display the Sun in the center with independent scaling
document.getElementById('talk-to-sun').addEventListener('click', function() {
    const solarFrame = document.getElementById('solar-frame');
    const sunFrame = document.getElementById('sun-frame');
    const talkToSunButton = document.getElementById('talk-to-sun');
    const talkToVenusButton = document.getElementById('talk-to-venus');

    // Fade out the solar system frame
    solarFrame.style.opacity = "0";

    setTimeout(() => {
        solarFrame.style.display = "none"; // Hide solar system frame
        sunFrame.style.display = "block"; // Show Sun view
        sunFrame.style.opacity = "1"; // Fade-in effect
        sunFrame.classList.add('large-view-sun'); // Scale up the Sun view with specific class

        // Hide "Talk to Sun" button and show "Talk to Venus" button
        talkToSunButton.classList.add('hidden');
        talkToVenusButton.classList.remove('hidden');
    }, 500); // Adjust delay to match fade-out duration
});

// Talk to Venus - Display Venus in the center with independent scaling
document.getElementById('talk-to-venus').addEventListener('click', function() {
    const sunFrame = document.getElementById('sun-frame');
    const venusFrame = document.getElementById('venus-frame');
    const talkToVenusButton = document.getElementById('talk-to-venus');

    // Immediately hide the Sun frame to prevent flickering
    sunFrame.style.opacity = "0";
    sunFrame.style.display = "none"; // Hide Sun frame instantly
    sunFrame.classList.remove('large-view-sun'); // Remove scale from Sun frame

    // Show the Venus frame after Sun is completely hidden
    setTimeout(() => {
        venusFrame.style.display = "block"; // Show Venus view
        venusFrame.style.opacity = "1"; // Fade-in effect
        venusFrame.classList.add('large-view-venus'); // Scale up the Venus view with specific class

        // Hide "Talk to Venus" button after Venus is displayed
        talkToVenusButton.classList.add('hidden');
    }, 50); // Short delay to ensure Venus appears smoothly after Sun is hidden
});
