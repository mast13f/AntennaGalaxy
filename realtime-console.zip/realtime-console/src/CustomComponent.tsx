import React, { useEffect, useRef, useCallback, useState } from 'react';
import { RealtimeClient } from '@openai/realtime-api-beta';
import { ItemType } from '@openai/realtime-api-beta/dist/lib/client.js';
import { config, instructions } from './conversation_config.js';

const CC: React.FC = () => {
  const clientRef = useRef<RealtimeClient | null>(null);
  const wavRecorderRef = useRef<any>(null);
  const wavStreamPlayerRef = useRef<any>(null);
  const startTimeRef = useRef<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [realtimeEvents, setRealtimeEvents] = useState<any[]>([]);
  const [items, setItems] = useState<ItemType[]>([]);

  useEffect(() => {
    // Initialize RealtimeClient
    const client = new RealtimeClient({
      apiKey: config.apiKey,
      url: config.relayServerUrl,
    });
    clientRef.current = client;

    // Connect to the Realtime API
    client.connect();

    // Send instructions after connection is established
    client.on('open', () => {
      client.sendUserMessageContent([
        {
          type: 'input_text',
          text: instructions,
        },
      ]);
    });

    // Event listener for receiving messages from the Realtime API
    client.on('message', (data: any) => {
      console.log('Message from server:', data);
      // Handle the received message (e.g., update the UI)
      if (data.type === 'error') {
        console.error('Error from server:', data);
      } else {
        updateConversationDisplay(data);
      }
    });

    // Cleanup on component unmount
    return () => {
      client.disconnect();
    };
  }, []);

  // Function to send messages to the Realtime API
  const sendMessageToServer = useCallback((message: string) => {
    const client = clientRef.current;
    if (client) {
      client.sendUserMessageContent([
        {
          type: 'input_text',
          text: message,
        },
      ]);
    }
  }, []);

  // Function to display conversation items in the UI
  const updateConversationDisplay = useCallback((items: any) => {
    const outputDiv = document.getElementById('console-output');
    if (outputDiv) {
      outputDiv.innerHTML = ''; // Clear previous conversation

      // Ensure items is an array
      const itemsArray = Array.isArray(items) ? items : [items];

      itemsArray.forEach((item: any) => {
        const newMessage = document.createElement('div');
        const sender = item.role === 'user' ? 'user' : 'assistant';
        newMessage.classList.add(sender);
        newMessage.textContent = item.text;  // Display the text message
        outputDiv.appendChild(newMessage);
      });
    }
  }, []);

  // Function to connect to the voice API and start recording
  const connectConversation = useCallback(async () => {
    const client = clientRef.current;
    const wavRecorder = wavRecorderRef.current;
    const wavStreamPlayer = wavStreamPlayerRef.current;

    if (client && wavRecorder && wavStreamPlayer) {
      // Set state variables
      startTimeRef.current = new Date().toISOString();
      setIsConnected(true);
      setRealtimeEvents([]);
      setItems(client.conversation.getItems());

      // Connect to microphone
      await wavRecorder.begin();

      // Connect to audio output
      await wavStreamPlayer.connect();

      // Connect to realtime API
      await client.connect();
      client.sendUserMessageContent([
        {
          type: 'input_text',
          text: 'Hello, Sun!',
        },
      ]);
    }
  }, []);

  // Example usage: Send a message when the "Talk to Sun" button is clicked
  useEffect(() => {
    const talkToSunButton = document.getElementById('talk-to-sun');
    if (talkToSunButton) {
      talkToSunButton.addEventListener('click', connectConversation);
    }

    // Cleanup event listener on component unmount
    return () => {
      if (talkToSunButton) {
        talkToSunButton.removeEventListener('click', connectConversation);
      }
    };
  }, [connectConversation]);

  // Explore the Solar System - Show solar system view and hide initial elements
  useEffect(() => {
    const transitionButton = document.getElementById('transition-button');
    if (transitionButton) {
      transitionButton.addEventListener('click', () => {
        const splineFrame = document.getElementById('spline-frame') as HTMLIFrameElement;
        const solarFrame = document.getElementById('solar-frame') as HTMLIFrameElement;
        const loadingSpinner = document.getElementById('loading-spinner');
        const talkToSunButton = document.getElementById('talk-to-sun');

        // Show loading spinner and fade out initial view
        if (loadingSpinner) loadingSpinner.classList.remove('hidden');
        if (splineFrame) splineFrame.style.opacity = "0";
        if (transitionButton) transitionButton.style.opacity = "0";

        setTimeout(() => {
          if (splineFrame) splineFrame.style.display = "none"; // Hide initial frame
          if (transitionButton) transitionButton.style.display = "none";
          if (loadingSpinner) loadingSpinner.classList.add('hidden'); // Hide loading spinner
          
          // Show solar system frame and "Talk to Sun" button
          if (solarFrame) {
            solarFrame.style.display = "block";
            solarFrame.style.opacity = "1"; // Fade-in effect
          }
          if (talkToSunButton) talkToSunButton.classList.remove('hidden');
        }, 500); // Adjust delay to match fade-out duration
      });
    }

    // Cleanup event listener on component unmount
    return () => {
      if (transitionButton) {
        transitionButton.removeEventListener('click', () => {
          const splineFrame = document.getElementById('spline-frame') as HTMLIFrameElement;
          const solarFrame = document.getElementById('solar-frame') as HTMLIFrameElement;
          const loadingSpinner = document.getElementById('loading-spinner');
          const talkToSunButton = document.getElementById('talk-to-sun');

          // Show loading spinner and fade out initial view
          if (loadingSpinner) loadingSpinner.classList.remove('hidden');
          if (splineFrame) splineFrame.style.opacity = "0";
          if (transitionButton) transitionButton.style.opacity = "0";

          setTimeout(() => {
            if (splineFrame) splineFrame.style.display = "none"; // Hide initial frame
            if (transitionButton) transitionButton.style.display = "none";
            if (loadingSpinner) loadingSpinner.classList.add('hidden'); // Hide loading spinner
            
            // Show solar system frame and "Talk to Sun" button
            if (solarFrame) {
              solarFrame.style.display = "block";
              solarFrame.style.opacity = "1"; // Fade-in effect
            }
            if (talkToSunButton) talkToSunButton.classList.remove('hidden');
          }, 500); // Adjust delay to match fade-out duration
        });
      }
    };
  }, []);

  return (
    <div data-component="CustomComponent">
      <iframe id="spline-frame" src="https://my.spline.design/particleplanet-e3c3489bca7beb8ae35f6b97825afc89/" allow="fullscreen"></iframe>
      <iframe id="solar-frame" src="https://my.spline.design/solarsystembasic-bb3ce38040d588a8b8c01462e42d57b5/" loading="lazy" allow="fullscreen" style={{ opacity: 0, display: 'none' }}></iframe>
      <iframe id="sun-frame" src="https://my.spline.design/solarsystembasic-51f20c0acef7c99cdd0334b0b5a6bef9/" loading="lazy" allow="fullscreen" style={{ opacity: 0, display: 'none' }}></iframe>
      <iframe id="venus-frame" src="https://my.spline.design/solarsystembasic-44a1a99ca0dd290a224b17ae34ce3eb6/" loading="lazy" allow="fullscreen" style={{ opacity: 0, display: 'none' }}></iframe>
      <button id="transition-button">Explore the Solar System</button>
      <button id="talk-to-sun" className="hidden">Talk to Sun</button>
      <button id="talk-to-venus" className="hidden">Talk to Venus</button>
      <div id="loading-spinner" className="hidden"></div>
      <div id="console-output"></div>
    </div>
  );
};

export default CC;