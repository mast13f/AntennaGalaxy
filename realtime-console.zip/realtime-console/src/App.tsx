import React from 'react';
import './App.scss';
import CC from './CC';

function App() {
  return (
    <div data-component="App">
      <CC />
    </div>
  );
}

export default App;